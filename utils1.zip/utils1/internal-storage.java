//ARMAZENAMENTO INTERNO
https://developer.android.com/guide/topics/data/data-storage?hl=pt-BR#filesInternal

//Para criar e gravar um arquivo privado no armazenamento interno:

//Chame openFileOutput() com o nome do arquivo e o modo operacional. Isso retorna um FileOutputStream.
//Grave no arquivo com write().
//Feche o stream com close().

// **********EXEMPLO*************

	//para escrever
            for(String linha:USERS_AND_PASSWORDS)//escreve na String USERS_AND_PASSWORDS declarada anteriormente
                arquivo.write(linha.getBytes());
            arquivo.close();

//Para ler um arquivo no armazenamento interno:

//Chame openFileInput() e passe o nome do arquivo a ler. Isso retorna um FileInputStream.
//Leia bytes do arquivo com read().
//E feche o stream com close().

// **********EXEMPLO*************