//Tela que inicia o App, apenas por alguns segundos

//JAVA
//esconder a action bar
getSupportActionBar().hide();
//setar a window como FULLSCREEN
getWindow().setFlags(WindowManager.LayoutParams.FULLSCREEN,WindowManager.LayoutParams.FULLSCREEN);


/*	Para esperar alguns segundos		Dentro de um 
					static final int tempoMilisegundos=3500;//t=3,5s
					new Handler.postDelayed(
						new Runnable(
							run(){
								
							}

						),tempoMilisegundos);
*/
startActivity(new Intent(getBaseContext(), MainActivity.this));//chamar a atividade
finish();// finalizar/fechar para quando voltar nao ir pra tela de boas vindas

//MANIFEST

//botar splash screen como LAUNCHER e MainActivity como DEFAULT