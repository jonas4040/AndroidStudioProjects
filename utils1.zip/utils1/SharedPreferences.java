//SharedPreferences != PreferenceActivity
https://developer.android.com/guide/topics/data/data-storage?hl=pt-BR#pref
//para salvar dados primitivos int,String,float, double, char, etc

/*
	--> getSharedPreferences() — use esse método se precisar de vários arquivos de preferência,
		identificados por nome e especificados no primeiro parâmetro.
		
	--> getPreferences() — use esse método se precisar de apenas um arquivo de preferência para a Activity.
		Como esse será o único arquivo de preferências para a Activity, o nome não é fornecido.
*/
static final String NOME="users_and_passwords";

//LER
SharedPreferences sharedPreferences=getSharedPreferences(NOME,MODO);//MODE_PRIVATE é o padrao para criar arquivo e le-lo MULTI_PROCESS(compartilhar com outros)
														  //está deprecated

//ESCREVER dentro do OnStop