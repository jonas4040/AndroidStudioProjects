//bkp

    public static LatLng setPosicao(double lat,double lng){//pega do Overlay
        LatLng p=new LatLng(    //ponto
                (int) (lat*1E6),
                (int) (lng*1E6)
        );
        return p;
    }//GeoPoint deprecated

    public void buscaCoordenadas(final String adress){
        final Geocoder geocoder=new Geocoder(this);

        //Caixa de progresso :D
       pd=ProgressDialog.show(this,"Carregando","Procurando Endereco...",true,false);

       //cria Thread para achar endereco do jeito antigo
        Thread achaEndereco;
        achaEndereco=new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    endEncontrado=geocoder.getFromLocationName(adress,1);//NAO alterar max results 2@param
                    Thread.sleep(1500);
                }catch (Exception e){
                    MainActivity main=new MainActivity();
                    main.mostraCxTexto("Erro buscando endereco: \n---> "+e.getMessage(),"ERRO 0x4A");//error adress in map
                }
                mostraListaEndereco.sendEmptyMessage(0);
            }
        });
        achaEndereco.start();
        mostraListaEndereco=new Handler(){
            @Override
            public void handleMessage(Message msg) {
                //super.handleMessage(msg);
                pd.dismiss();

                //INSTANCIA
                //se nao localizar endereco mostra um erro
                if(endEncontrado!=null) {
                    if (endEncontrado.size() == 0) {
                        Toast.makeText(getBaseContext(), "Endereco nao localizado: ", Toast.LENGTH_SHORT).show();
                    } else {
                        for (int i = 0; i < endEncontrado.size(); ++i) {
                            Address x = endEncontrado.get(i);
                            local = x.getAddressLine(i);
                            lat = x.getLatitude();
                            lon = x.getLongitude();

                            //Log.d(null, "EnderecoX--> " + x +
                              //      "\n\tlocal--->" + local +
                                //    "\n\t\tLatitude: " + lat + " e  Longitude: " + lon);
                        }
                        Toast.makeText(getBaseContext(), "Endereco: " + local, Toast.LENGTH_LONG).show();
                    }
                }else {
                    Log.d(null, "\t\tERRO FATAR!!!!");
                }
            }
        };
    }