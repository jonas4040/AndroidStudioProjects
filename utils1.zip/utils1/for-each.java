//é um for normal, porém, usado com Arrays
//evita o IndexBoundException

int count= new  int[10];
String str={"teste","exemplo"};
//A sintaxe do for each é a seguinte:
for ( tipo variavel_do_tipo_do_seuArray : seuArray){
 //seu código
}

//Se o 'seuArray' for de inteiro, ficaria:
for (int count : seuArray){
//... nao precisa por colchetes
}

//Se o 'seuArray' for de String, ficaria:
for (String str : seuArray){
//... nao precisa por colchetes
}