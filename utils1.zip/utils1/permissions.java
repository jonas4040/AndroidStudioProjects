//Para verificar se você tem uma permissão, chame o método ContextCompat.checkSelfPermission()

//Se o aplicativo tiver a permissão, o método retornará PackageManager.PERMISSION_GRANTED e o aplicativo poderá continuar com a operação.
// Se o aplicativo não tiver a permissão, o método retornará PERMISSION_DENIED e o aplicativo precisará solicitar a permissão do usuário explicitamente.

if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            
			//sera que devemos mostrar uma explicacao ao user?
			if(ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,Manifest.permission.CALL_PHONE)){

			}else{
				ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.CALL_PHONE},CONSTANTE);//pode ser == 1
			}
			
            return;
}