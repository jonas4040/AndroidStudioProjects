/*
* ********IMPLEMENTAR CLASSE USUARIO com cidade(obrig) e estado(obrig) e telefone(opcional)*********
* */

package com.packsendme.login;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class CadastroActivity extends AppCompatActivity {

    EditText txtNome,txtTelefone,txtCidade,txtEmail,txtPassword,txtConfPassword;
    Spinner spnEstados;
    Button btnCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        getSupportActionBar().setTitle("Cadastrar");
        txtCidade=findViewById(R.id.txtCidade);
        txtConfPassword=findViewById(R.id.txtConfPassword);
        txtEmail=findViewById(R.id.txtEmail);
        txtPassword=findViewById(R.id.txtPassword);
        txtTelefone=findViewById(R.id.txtTelefone);
        txtNome=findViewById(R.id.txtNome);
        btnCadastrar=findViewById(R.id.btnCadastrar);
        spnEstados=findViewById(R.id.spnEstados);

        //getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setH
    }

    //botao voltar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home :finish();break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void validaCadastro(View view){
        TextView tvEstado=findViewById(R.id.tvEstado);

        //email
        if(txtNome.getText().toString().isEmpty() ||
                txtEmail.getText().toString().isEmpty() ||
                txtPassword.getText().toString().isEmpty() ||
                spnEstados.getSelectedItem().equals("Selecione um Estado")
        ){
            tvEstado.setError("Selecione um Estado");
            String empty="Campo obrigatório";
            txtNome.setError(empty);
            txtEmail.setError(empty);
            txtPassword.setError(empty);

        }else if(!txtEmail.getText().toString().contains("@")||!txtEmail.getText().toString().contains(".com")){
            txtEmail.setError("Digite um e-mail válido");
        }else if(!txtConfPassword.getText().toString().equals(txtPassword.getText().toString())){
            txtPassword.setError("Parece que as senhas são diferentes");
            txtConfPassword.setError("Digite a senha novamente");
        }else if(spnEstados.getSelectedItem().equals("Selecione um Estado")){
            tvEstado.setError("Selecione um Estado");
        }else{
            Toast.makeText(getBaseContext(),"Te mandaremos um e-mail de confirmacão em poucos instantes", Toast.LENGTH_LONG).show();
        }

    }
}
