package com.packsendme.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MyLoginActivity extends AppCompatActivity {

    private Button btnEntrar;
    private EditText txtEmail,txtPassword;
    private TextView tvCadastrar;
    ProgressBar progressBar;

    static final String[] USERS_AND_PASSWORDS={"foo@example.com:hello","email@email.com:123456","jonas@jonas.com:asdf"};

    //salvar no armazenamento interno
    //String NOME_ARQUIVO="config";

    //salvar em arquivo de preferencias SharedPreferences
    //static final String NOME="users_and_passwords";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_login);

        //inicializa componentes
        tvCadastrar=findViewById(R.id.tvCadastrar);
        txtEmail=findViewById(R.id.txtEmail);
        txtPassword=findViewById(R.id.txtPassword);
        btnEntrar=findViewById(R.id.btnEntrar);
        progressBar=findViewById(R.id.progressBar);

        tvCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getBaseContext(),CadastroActivity.class));
            }
        });

        /*try {
            //FileOutputStream arquivo=openFileOutput(NOME_ARQUIVO,MODE_PRIVATE);

            //para escrever
            for(String linha:USERS_AND_PASSWORDS)
                arquivo.write(linha.getBytes());
            arquivo.close();
        } catch (FileNotFoundException e) {
            Log.i(null,"NAo foi possivel encontrar o arquivo\n\n\t "+e.getMessage());
            Log.d(null,"NAo foi possivel encontrar o arquivo\n\n\t "+e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            Log.i(null,"Erro de entrada/saída\n\n\t "+e.getMessage());
            Log.d(null,"Erro de entrada/saída\n\n\t "+e.getMessage());
            e.printStackTrace();
        }*/

        //SharedPreferences sharedPreferences=getSharedPreferences(NOME,MODE_PRIVATE);

        //USERS_AND_PASSWORDS=sharedPreferences.getString("USERS_AND_PASSWORDS","email@email.com:123456");

        progressBar.animate().alpha(0).setDuration(500).start();
        //quando entrar
        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Snackbar.make(v,"Carregando...",Snackbar.LENGTH_SHORT).show();//coloca numa View
                fazAutenticacao();
                //progressBar.animate().alpha(1).setDuration(500).start();

            }
        });
    }

    public void fazAutenticacao() {
        String mEmail,mPassword;
        mEmail=txtEmail.getText().toString();
        mPassword=txtPassword.getText().toString();
        /*
        try {
            FileInputStream arquivo=openFileInput(NOME_ARQUIVO);
            try {
                String ai=arquivo.;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        */

        for (String credenciais: USERS_AND_PASSWORDS){
            //pedaco[0] é o user e o pedaco[1] eh password
            String[] pedaco=credenciais.split(":");

            //IFS AQUI
            if(txtEmail.getText().toString().isEmpty() || txtPassword.getText().toString().isEmpty()){
                //txtEmail.setError("");
                Toast.makeText(getBaseContext(), "Nenhum campo pode ficar em branco,\n verifique se voce digitou corretamente.", Toast.LENGTH_LONG).show();
            }else{
                if(!credenciais.contains("@")){
                    txtEmail.setError("Digite um e-mail válido.");
                }else {

                    if (!pedaco[0].equals(mEmail) || !pedaco[1].equals(mPassword)) {
                        Log.d(null, "\n\n\tDEU RUIM");
                        txtEmail.setError("Verifique se voce digitou o e-mail corretamente.");
                        txtPassword.setError("Verifique se voce digitou a senha corretamente.");
                    } else {//se forem todos iguais
                        Log.d(null, "\n\n\tDEU CERTO");
                        progressBar.animate().alpha(1).setDuration(500).start();
                        finish();
                        startActivity(new Intent(getBaseContext(), MainActivity.class));
                    }
                }
            }

            //Log.d(null,"\n\n\nPedaco 1: "+pedaco[0]+"\n\tPedaco 2: "+pedaco[1]);
        }
    }
}
