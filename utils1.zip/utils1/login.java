//Login

//campos de texto(EditText ou TextField)
String mEmail,mPassword;

mEmail=txtEmail.getText().toString();
mPassword=txtPassword.getText().toString();

//LOOP QUE PERCORRE String[]={"user1:pass1",...,"userN:passN"}
for (String credenciais: USERS_AND_PASSWORDS){
            //pedaco[0] é o user e o pedaco[1] eh password
            String[] pedaco=credenciais.split(":");
            
            //IFS AQUI
            
            Log.d(null,"\n\n\nPedaco 1: "+pedaco[0]+"\n\tPedaco 2: "+pedaco[1]);//CUIDADO NO INDICE
}

//IFS QUE VERIFICAM O LOGIN
if(txtEmail.getText().toString().isEmpty() || txtPassword.getText().toString().isEmpty()){
                Toast.makeText(getBaseContext(), "Nenhum campo pode ficar em branco,\n verifique se voce digitou corretamente.", Toast.LENGTH_LONG).show();
            }else{
                if (!pedaco[0].equals(mEmail) || !pedaco[1].equals(mPassword)) {//CUIDADO NO INDICE
                    Log.d(null,"\n\n\tDEU RUIM");
                    txtEmail.setError("Verifique se voce digitou o e-mail corretamente.");
                    txtPassword.setError("Verifique se voce digitou a senha corretamente.");
                } else {//se forem todos iguais
                    Log.d(null,"\n\n\tDEU CERTO");
                    progressBar.animate().alpha(1).setDuration(500).start();
                    finish();
                    startActivity(new Intent(getBaseContext(), MainActivity.class));
                }
            }
