interface TarefasInterface{
	
	public void depoisDaMacumba(Macumba macumba);

}