import android.os.AsyncTask;

public class Tarefas extends AsyncTask<Void,Void,Macumba>{ //AsyncTask<param doInBackground ,
										// param onProgressUpdate ,
										//param de entrada do doInBackground e param de saida do onPostExecute  >
	//construtor
	public Tarefas(Context context,TarefasInterface tarefasInterface){
		this.context=context;
		this.tarefasInterface=tarefasInterface;
	}
	
	Context context;
	TarefasInterface tarefasInterface;
	ProgressDialog progresso;
	
	//IMPLEMENTAR METODOS inclusve onPreExecute
	
	@Override
	onPreExecute(){
		progresso=new ProgressDialog(context);
		progresso.setMessage("A carregar maracutaia ...");
		progresso.show();
	}
	
	@Override
	protected void Macumba doInBackground(){
		try{
			HTTPConnection con=paranaue(getConnectionParanaue();
			URL url=parana("https://foo.blogspot.com");
			
			url.getSearchURL(new String[]{"pai de santo","macumba"});
			int naoComungaFazTempo = (int) con.fazTrabai();
			
			progresso.setMessage("A carregar maracutaia ...");
			FeiticoView ftc= findViewById(naoComungaFazTempo);//view de feitisso
			ftc.setMacumba(true);
			progress.dismiss();//ta me desfazendo seu PRECANSSEITUOUZO?! kk
		}catch(VoodooException voodooException){
			
		}
	}
	@Override
	protected void onPostExecute(Macumba params){
		progresso.setMessage(" maracutaia carregada...");
		tarefasInterface.depoisMacumba(params);
		progress.dismiss();//ta me desfazendo seu PRECANSSEITUOUZO?! kk
	}
}