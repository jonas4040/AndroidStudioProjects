package com.packsendme.slidertaskv1;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URI;

public class MainActivity extends AppCompatActivity {

    public static final int PICK_IMAGE = 1;
    private TextView tvChooseFile;
    private Button btnChooseFile;
    private ImageView imgContent;
    ProgressDialog progresso;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_img1:
                    tvChooseFile.setText(R.string.title_home);
                    //imgContent.setImageResource();
                    //imgContent.setImageURI(uri);
                    return true;
                case R.id.navigation_img2:
                    tvChooseFile.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_img3:
                    tvChooseFile.setText(R.string.title_notifications);
                    return true;
                case R.id.navigation_img4:
                    tvChooseFile.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvChooseFile = (TextView) findViewById(R.id.tv_choose_file);
        btnChooseFile = findViewById(R.id.btnChooseFile);
        imgContent = findViewById(R.id.imgContent);
        //progresso=new ProgressDialog(MainActivity.this);
        //progresso
        progresso=new ProgressDialog(this.getApplicationContext());
        progresso.setMessage("Carregando imagem ...");
        //Toast.makeText(getBaseContext(), "Progresso: "+progresso, Toast.LENGTH_LONG).show();
        Log.d(null,"Progresso: "+progresso.getWindow());
        //progresso.setProgress(30);
        //progresso.set

        //progresso.show();

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        //btnChooseFile.setOnClickListener(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (resultCode == RESULT_OK) {
                if (requestCode == PICK_IMAGE) {
                    Uri imgSelecionadaUri = data.getData();//pega do Intent
                    CarregaImagemTask carregaImagemTask=new CarregaImagemTask(this.getApplicationContext(),imgSelecionadaUri);
                    carregaImagemTask.execute();

                    //findview
                    imgContent.setImageURI(imgSelecionadaUri);
                }
            }
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), "ERRO\n\t----> " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    class CarregaImagemTask extends AsyncTask<Void, Void, Bitmap> {

         //ProgressDialog progresso;
         Context context;

         public CarregaImagemTask(Context context,Uri caminhoImg) {
             this.caminhoImg = caminhoImg;
             this.context=context;
         }

         private Uri caminhoImg;

         @Override
         protected void onPreExecute() {
             //super.onPreExecute();
             //progresso=findViewById(R)
             //progresso = new ProgressDialog(context);//
             /*try {
                 Thread.sleep(10000);
             } catch (InterruptedException e) {
                 e.printStackTrace();
             }*/

             //PROGRESS DIALOG AQUI
         }

         @Override
         protected Bitmap doInBackground(Void... voids) {
             try {
                 InputStream imgStream = getContentResolver().openInputStream(caminhoImg);
                 Thread.sleep(10000);
                 return BitmapFactory.decodeStream(imgStream);

             } catch (FileNotFoundException e) {
                 Toast.makeText(getBaseContext(), "Erro ao escolher arquivo  " + caminhoImg + " \n\t--->  " + e.getMessage(), Toast.LENGTH_LONG).show();
             } catch (InterruptedException e) {
                 e.printStackTrace();
             }
             return null;
         }

         @Override
         protected void onPostExecute(Bitmap bitmap) {
             //super.onPostExecute(bitmap);
             progresso.setMessage("Imagem carregada com sucesso :D");
//             progresso.show();
             imgContent = findViewById(R.id.imgContent);
             imgContent.setVisibility(View.VISIBLE);

             //progresso.dismiss();
             progresso.cancel();
         }
         //barra de progresso


         @Override
         protected void onProgressUpdate(Void... values) {
             super.onProgressUpdate(values);
             progresso.show();
         }
     }

     public void escolheImagem (View mView){
         Toast.makeText(getBaseContext(), "Lembre-se de escolher somente GIFS!", Toast.LENGTH_LONG).show();
         //new EscolheArquivoTask().execute();

         Intent intent = new Intent();
         intent.setType("image/*");
         intent.setAction(Intent.ACTION_GET_CONTENT);
         startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
         //startAct

         //progresso.show();
     }

}
