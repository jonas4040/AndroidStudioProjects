package com.packsendme.slidertaskv1;

import android.os.AsyncTask;
import android.widget.ImageView;

import java.net.URI;

public class EscolheArquivoTask extends AsyncTask<URI,Integer, ImageView> {

    @Override
    protected ImageView doInBackground(URI... uris) {
        return null;
    }

    @Override
    protected void onPostExecute(ImageView imageView) {
        //update UI
        super.onPostExecute(imageView);
        //EXIBE IMAGEM
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        //PROGRESSO UI
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPreExecute() {
        //MOSTRA BARRA DE PROGRESSO
        super.onPreExecute();
    }
}
