package com.packsendme.firstroom;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.Room;
//import android.annotation.NonNull;
import android.content.Context;

@Database(entities = {Cadastro.class},version = 1)
public abstract class CadastroDatabase extends RoomDatabase {
    private static final String DB_NAME="bdcadastro3.db";
    private static volatile CadastroDatabase instance;

    static  synchronized CadastroDatabase getInstance(Context context){//somente criar UMA instancia de classe
        if(instance== null) {
            instance = create(context);
        }
        return instance;
    }

    private static CadastroDatabase create(final Context context){
        //CRIA O BD
        return Room.databaseBuilder(context,CadastroDatabase.class,DB_NAME).build();
    }

    public abstract CadastroDAO getCadastroDao();
}
