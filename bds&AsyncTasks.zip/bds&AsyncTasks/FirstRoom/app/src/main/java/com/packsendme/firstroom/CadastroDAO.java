package com.packsendme.firstroom;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.database.Cursor;

@Dao
public interface CadastroDAO {
    //AQUI SE CRIAM AS QUERIES SQL
    //pode-se repetir os annotations para varias operaoes com @params diferentes

    @Query("SELECT * FROM cadastro")//por enquanto
    Cursor getAllRegsCursor();

    @Insert
    void insert(Cadastro... cadastroEntities);

    /*

    @Update
    void update(Cadastro... cadastroEntities);

    @Delete
    void delete(Cadastro... cadastroEntities);
    */
}
