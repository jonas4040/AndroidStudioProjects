package com.packsendme.firstroom;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity
public class Cadastro {
    @PrimaryKey
    public final int id;
    public final String nome;
    public final String endereco;
    public final String telefone;

    public Cadastro(int id, String nome, String endereco, String telefone) {
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
    }
}
