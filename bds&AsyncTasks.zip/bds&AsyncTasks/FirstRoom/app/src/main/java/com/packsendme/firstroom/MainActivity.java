package com.packsendme.firstroom;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    TextView tvDeuCerto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvDeuCerto=findViewById(R.id.tvDeuCerto);

    try {
        tvDeuCerto.setText("Deu certo");

        //TEM QUE SER EM BACKGROUND SEM ASYNCTASK
        Executor tarefa = Executors.newSingleThreadExecutor();
        tarefa.execute(() -> {
            CadastroDatabase.getInstance(getBaseContext()).getCadastroDao().insert(new Cadastro(1, "Jonas", "Rua felumines, 77", "93544-8888"));
        });


    }catch (Exception e){
        tvDeuCerto.setText("OPA! --> "+e.getMessage());
        e.printStackTrace();
    }
        /*InsereDados insereDados = new InsereDados(getApplicationContext());
        insereDados.execute();
        insereDados.getStatus();*/
    }
/* DANDO ERRO DE RETORNO void do DAO mas Void da tarefa
    public class InsereDados extends AsyncTask<Void,Void,Void>{
        Context context;
        @Override
        protected Void doInBackground(Void... voids) {
            return CadastroDatabase.getInstance(getBaseContext()).getCadastroDao().insert(new Cadastro(1,"Jonas","Rua felumines, 77","93544-8888"));
            //.getCadastroDao().insert(new Cadastro(1,"Jonas","Rua felumines, 77","93544-8888"))
        }//<Params,Progress,Results>

        public InsereDados(Context context) {
            this.context = context;
        }
    }
    */
}
